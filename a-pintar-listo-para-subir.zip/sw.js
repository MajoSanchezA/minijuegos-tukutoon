const CACHE_NAME = 'tukutoon-a-pintar-v20';
const APP_SHELL = [
  './',
  './index.html',
  './paginas.js',
  './js/script.js',
  './js/musica-fondo.js',
  './css/style.css',
  './fonts/fonts.css',
  './fonts/Comfortaa-latin.woff2',
  './fonts/Fredoka-latin.woff2',
  './fondo-menu.png',
  './fondo-mesa.png',
  './fondo-dibujo.svg',
  './fondo-dibujo.png',
  './hoja-dibujo.png',
  './logo-tukutoon-horizontal.png',
  './motor-v18.js',
  './motor-v18.css',
  './audio/pincel_bucle.wav',
  './audio/lapiz_bucle.wav',
  './audio/borrador_bucle.wav',
  './audio/balde_pintura.wav',
  './audio/musica-fondo.mp3',
  './iconos/borrador.png',
  './iconos/balde.png',
  './iconos/descargar.png',
  './iconos/especial.png',
  './iconos/lapiz.png',
  './iconos/pincel.png',
  './iconos/reiniciar.png',
  './iconos/salir.png',
  './colorea-tukutoon-aida.html',
  './paginas/aida/aida.png',
  './colorea-tukutoon-ana.html',
  './paginas/ana/ana.png',
  './colorea-tukutoon-gabo.html',
  './paginas/gabo/gabo.png',
  './colorea-tukutoon-tico.html',
  './paginas/tico/tico.png',
  './colorea-tukutoon-tuku.html',
  './paginas/tuku/tuku.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((key) => key.startsWith('tukutoon-a-pintar-') && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (!response.ok) return response;
          return caches.open(CACHE_NAME)
            .then((cache) => cache.put(request, response.clone()))
            .then(() => response);
        })
        .catch(async () => {
          const cached = await caches.match(request, { ignoreSearch: true });
          return cached || caches.match(new URL('./index.html', self.registration.scope).href);
        })
    );
    return;
  }

  event.respondWith(
  caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (!response.ok) return response;
        return caches.open(CACHE_NAME)
          .then((cache) => cache.put(request, response.clone()))
          .then(() => response);
      });
    })
  );
});
