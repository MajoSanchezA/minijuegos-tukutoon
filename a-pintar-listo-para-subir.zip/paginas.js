/* Dibujos disponibles en el menú de A pintar. */
const PAGINAS = [
  {
    id: 'aida',
    nombre: 'Aida',
    miniatura: 'paginas/aida/aida.png',
    url: './colorea-tukutoon-aida.html'
  },
  {
    id: 'ana',
    nombre: 'Ana',
    miniatura: 'paginas/ana/ana.png',
    url: './colorea-tukutoon-ana.html'
  },
  {
    id: 'tuku',
    nombre: 'Tuku',
    miniatura: 'paginas/tuku/tuku.png',
    url: './colorea-tukutoon-tuku.html'
  },
  {
    id: 'gabo',
    nombre: 'Gabo',
    miniatura: 'paginas/gabo/gabo.png',
    url: './colorea-tukutoon-gabo.html'
  },
  {
    id: 'tico',
    nombre: 'Tico',
    miniatura: 'paginas/tico/tico.png',
    url: './colorea-tukutoon-tico.html'
  }
];
